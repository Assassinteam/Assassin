#آموزش نصب
cd $HOME
git clone https://github.com/Assassinteam/Assassin.git
cd Assassin
chmod +x Assassin.sh
./Assassin.sh install
./Assassin.sh 
# شمارتونو بزنید   & بعدش  کد تاییدیه.

➖➖➖➖➖➖➖➖➖➖➖
#آموزش اتولانچ :
chmod 777 autoasn.sh
screen ./autoasn.sh
```
➖➖➖➖➖➖➖➖➖➖➖
# اینجا خواستید همه را باهم گپی کنید در سرورتان پست کنید 
cd $HOME && git clone https://github.com/Assassinteam/Assassin.git && cd Assassin && chmod +x ‌Assassin.sh && ./Assassin.sh install && ./Assassin.sh

OR

cd $HOME && git clone https://github.com/Assassinteam/Assassin.git && cd Assassin && chmod +x Assassin.sh && ./Assassin.sh install && chmod 777 autoas.sh && screen ./autoas.sh
```
➖➖➖➖➖➖➖➖➖➖➖

#لینک گپ پشتیبانی اساسین

More information [Assasainteam Chat](https://t.me/joinchat/Do0Xm0O1XhqL5mT6bG7hCw)

➖➖➖➖➖➖➖➖➖➖➖
# Developers!

[Amir](https://github.com/khas222) ([Telegram](https://telegram.me/khas222))

➖➖➖➖➖➖➖➖➖➖➖
# کانال ما:

[@AssassinsteaM](https://telegram.me/AssAssinsTeaM)
